import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

public class TopFiveDestinationList {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
            	TopDestinationListFrame topDestinationListFrame = new TopDestinationListFrame();
                topDestinationListFrame.setTitle("Jose's Top 5 Destination List");
                topDestinationListFrame.setVisible(true);
            }
        });
    }
}


class TopDestinationListFrame extends JFrame {
    private DefaultListModel listModel;

    public TopDestinationListFrame() {
        super("Top Five Destination List");

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setSize(900, 750);

        listModel = new DefaultListModel();


        //Make updates to your top 5 list below. Import the new image files to resources directory.
        addDestinationNameAndPicture("1. Santorini, Greece. Santorini is a stunning Greek island known for its breathtaking sunsets, architecture, and beaches.", new ImageIcon(getClass().getResource("/resources/Greece.jpg")));
        addDestinationNameAndPicture("2. Rome, Italy. Rome is a timeless city known for its ancient ruins, vibrant culture, and rich history.", new ImageIcon(getClass().getResource("/resources/Rome.jpg")));
        addDestinationNameAndPicture("3. Bora Bora. Bora is a stunning tropical paradise known for its crystal clear water and luxurious bungalows.", new ImageIcon(getClass().getResource("/resources/Bora.jpg")));
        addDestinationNameAndPicture("4. Tokyo, Japan. Tokyo is a dynamic city known for its skyscrapers, historic landmarks, and thriving cultural scene that showcases modern innovation and traditonal Japanese heritage.", new ImageIcon(getClass().getResource("/resources/Japan1.jpg")));
        addDestinationNameAndPicture("5. Dubai, United Arab Emirates. Dubai is a dazzling city renowed for its futuristic skyline, luxurious shopping, and extravagent attractions.", new ImageIcon(getClass().getResource("/resources/Dubai.jpg")));
        
        //Creates JLabel for name with size on font
		JLabel lblJoseLopez = new JLabel("Developer: Jose Lopez");
		lblJoseLopez.setFont(new Font("Tahoma", Font.BOLD, 18));
		
        JList list = new JList(listModel);
        JScrollPane scrollPane = new JScrollPane(list);
       

        TextAndIconListCellRenderer renderer = new TextAndIconListCellRenderer(2);

        list.setCellRenderer(renderer);

        //Adds scroll pane and new label to screen also changes text and background color
        getContentPane().add(scrollPane, BorderLayout.CENTER);
        getContentPane().add(lblJoseLopez, BorderLayout.NORTH);
        getContentPane().setBackground(Color.LIGHT_GRAY);
        list.setFont(new Font("Tahoma", Font.PLAIN, 14));
        list.setForeground(Color.WHITE);
        list.setBackground(Color.BLACK);
        scrollPane.setForeground(Color.YELLOW);
        scrollPane.setBackground(Color.YELLOW);
    }

    private void addDestinationNameAndPicture(String text, Icon icon) {
        TextAndIcon tai = new TextAndIcon(text, icon);
        listModel.addElement(tai);
    }
}


class TextAndIcon {
    private String text;
    private Icon icon;

    public TextAndIcon(String text, Icon icon) {
        this.text = text;
        this.icon = icon;
    }

	public String getText() {
        return text;
    }

    public Icon getIcon() {
        return icon;
    }

    public void setText(String text) {
        this.text = text;
    }

    public void setIcon(Icon icon) {
        this.icon = icon;
    }
}


class TextAndIconListCellRenderer extends JLabel implements ListCellRenderer {
    private static final Border NO_FOCUS_BORDER = new EmptyBorder(1, 1, 1, 1);

    private Border insideBorder;

    public TextAndIconListCellRenderer() {
        this(0, 0, 0, 0);
    }

    public TextAndIconListCellRenderer(int padding) {
        this(padding, padding, padding, padding);
    }

    public TextAndIconListCellRenderer(int topPadding, int rightPadding, int bottomPadding, int leftPadding) {
        insideBorder = BorderFactory.createEmptyBorder(topPadding, leftPadding, bottomPadding, rightPadding);
        setOpaque(true);
    }

    public Component getListCellRendererComponent(JList list, Object value,
    int index, boolean isSelected, boolean hasFocus) {
        // The object from the combo box model MUST be a TextAndIcon.
        TextAndIcon tai = (TextAndIcon) value;

        // Sets text and icon on 'this' JLabel.
        setText(tai.getText());
        setIcon(tai.getIcon());

        //Once selected these changes will change the color of the selection 
        if (isSelected) {
            //setBackground(list.getSelectionBackground());
            //setForeground(list.getSelectionForeground());
        	setBackground(Color.LIGHT_GRAY);
        	setForeground(Color.BLACK);
        	
        } else {
            setBackground(list.getBackground());
            setForeground(list.getForeground());
        }

        Border outsideBorder;

        if (hasFocus) {
            outsideBorder = UIManager.getBorder("List.focusCellHighlightBorder");
        } else {
            outsideBorder = NO_FOCUS_BORDER;
        }

        setBorder(BorderFactory.createCompoundBorder(outsideBorder, insideBorder));
        setComponentOrientation(list.getComponentOrientation());
        setEnabled(list.isEnabled());
        setFont(list.getFont());

        return this;
    }

    // The following methods are overridden to be empty for performance
    // reasons. If you want to understand better why, please read:
    //
    // http://java.sun.com/javase/6/docs/api/javax/swing/DefaultListCellRenderer.html#override

    public void validate() {}
    public void invalidate() {}
    public void repaint() {}
    public void revalidate() {}
    public void repaint(long tm, int x, int y, int width, int height) {}
    public void repaint(Rectangle r) {}
}